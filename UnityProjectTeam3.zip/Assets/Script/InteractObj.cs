﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Jobs;

public class InteractObj : MonoBehaviour
{
    public Transform player;
    private Rigidbody2D mRB;
    bool hasPlayer = false;
    bool beingCarried = false;
    private bool touched = false;
    // Start is called before the first frame update
    void Start()
    {
        mRB = this.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        float dis = Vector3.Distance(gameObject.transform.position, player.position);

        if(hasPlayer && Input.GetKeyDown(KeyCode.A))
        {
            GetComponent<Rigidbody2D>().isKinematic = true;
            transform.parent = player.transform;
            beingCarried = true;
        }
        else
        {
            GetComponent<Rigidbody2D>().isKinematic = false;
        }

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            hasPlayer = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            hasPlayer = false;
        }
    }

}
